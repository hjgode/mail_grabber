
Imports System.Collections.Generic
Imports System.Text
Imports System.IO
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Runtime.InteropServices.ComTypes
Imports System.ComponentModel
Imports ProfMan
Imports System.Threading


Namespace ProfMan

    Public NotInheritable Class ProfManLoader

#Region "public methods"

        '64 bit dll location - defaults to <assemblydir>\ProfMan64.dll
        Public Shared DllLocation64Bit As String
        '32 bit dll location - defaults to <assemblydir>\ProfMan.dll
        Public Shared DllLocation32Bit As String
        'The only creatable RDO object - RDOSession
        Public Shared Function new_Profiles() As Profiles
            Return DirectCast(NewProfManObject(New Guid("EBC7A7B5-C614-47B3-A579-27A2C2C98A13")), Object)
        End Function
        'Safe*Item objects
        Public Shared Function new_PropertyBag() As PropertyBag
            Return DirectCast(NewProfManObject(New Guid("FC583D50-A2F5-4656-8B1D-360488B183D3")), Object)
        End Function
        
#End Region

#Region "private methods"

        Shared Sub New()
            'use CodeBase instead of Location because of Shadow Copy.
            Dim vUri As UriBuilder = New UriBuilder(Assembly.GetExecutingAssembly().CodeBase)
            Dim vPath As String = Uri.UnescapeDataString(vUri.Path + vUri.Fragment)
            Dim directory As String = Path.GetDirectoryName(vPath)
            DllLocation64Bit = Path.Combine(directory, "ProfMan64.dll")
            DllLocation32Bit = Path.Combine(directory, "ProfMan.dll")


        End Sub

        <ComVisible(False)> _
        <ComImport(), InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("00000001-0000-0000-C000-000000000046")> _
        Private Interface IClassFactory
            Sub CreateInstance(<MarshalAs(UnmanagedType.[Interface])> ByVal pUnkOuter As Object, ByRef refiid As Guid, <MarshalAs(UnmanagedType.[Interface])> ByRef ppunk As Object)
            Sub LockServer(ByVal fLock As Boolean)
        End Interface

        <ComVisible(False)> _
        <ComImport(), InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("00000000-0000-0000-C000-000000000046")> _
        Private Interface IUnknown
        End Interface

        Private Delegate Function DllGetClassObject(ByRef ClassId As Guid, ByRef InterfaceId As Guid, <Out(), MarshalAs(UnmanagedType.[Interface])> ByRef ppunk As Object) As Integer
        Private Delegate Function DllCanUnloadNow() As Integer



        'win32 functions to load\unload dlls and get a function pointer
        Private Class Win32NativeMethods
            <DllImport("kernel32.dll", CharSet:=CharSet.Ansi, SetLastError:=True)> _
            Public Shared Function GetProcAddress(ByVal hModule As IntPtr, ByVal lpProcName As String) As IntPtr
            End Function
            <DllImport("kernel32.dll", SetLastError:=True)> _
            Public Shared Function FreeLibrary(ByVal hModule As IntPtr) As Boolean
            End Function
            <DllImport("kernel32.dll", CharSet:=CharSet.Unicode, SetLastError:=True)> _
            Public Shared Function LoadLibraryW(ByVal lpFileName As String) As IntPtr
            End Function
        End Class

        'private variables
        Private Shared _ProfManDllHandle As IntPtr = IntPtr.Zero
        Private Shared _dllGetClassObjectPtr As IntPtr
        Private Shared _dllGetClassObject As DllGetClassObject

        Private Shared _mutex As New Mutex

        'COM GUIDs
        Private Shared IID_IClassFactory As New Guid("00000001-0000-0000-C000-000000000046")
        Private Shared IID_IUnknown As New Guid("00000000-0000-0000-C000-000000000046")

        Private Shared Function NewProfManObject(ByVal guid As Guid) As IUnknown
            Dim res As Object = Nothing
            _mutex.WaitOne()
            Try
                If _ProfManDllHandle.Equals(IntPtr.Zero) Then
                    Dim dllPath As String
                    If IntPtr.Size = 8 Then
                        dllPath = DllLocation64Bit
                    Else
                        dllPath = DllLocation32Bit
                    End If
                    _ProfManDllHandle = Win32NativeMethods.LoadLibraryW(dllPath)
                    If _ProfManDllHandle.Equals(IntPtr.Zero) Then
                        'Throw New Exception(String.Format("Could not load '{0}'" & vbLf & "Make sure the dll exists.", dllPath))
                        Throw New Win32Exception(Marshal.GetLastWin32Error())
                    End If
                    _dllGetClassObjectPtr = Win32NativeMethods.GetProcAddress(_ProfManDllHandle, "DllGetClassObject")
                    If _dllGetClassObjectPtr.Equals(IntPtr.Zero) Then
                        'Throw New Exception("Could not retrieve a pointer to the 'DllGetClassObject' function exported by the dll")
                        Throw New Win32Exception(Marshal.GetLastWin32Error())
                    End If
                    _dllGetClassObject = DirectCast(Marshal.GetDelegateForFunctionPointer(_dllGetClassObjectPtr, GetType(DllGetClassObject)), DllGetClassObject)
                End If


                Dim unk As Object = Nothing
                Dim hr As Integer = _dllGetClassObject(guid, IID_IClassFactory, unk)
                If hr <> 0 Then
                    Throw New Exception("DllGetClassObject failed with error code" & hr.ToString("X8"))
                End If

                Dim ClassFactory As IClassFactory
                ClassFactory = unk 'DirectCast(unk, IClassFactory)
                ClassFactory.CreateInstance(Nothing, IID_IUnknown, res)
                'If the same class factory is returned as the one still
                'referenced by .Net, the call will be marshalled to the original thread
                'where that class factory was retrieved first.
                'Make .Net forget these objects
                Marshal.ReleaseComObject(unk)
                Marshal.ReleaseComObject(ClassFactory)
            Finally
                _mutex.ReleaseMutex()
            End Try

            Return TryCast(res, IUnknown)
        End Function

#End Region

    End Class



End Namespace