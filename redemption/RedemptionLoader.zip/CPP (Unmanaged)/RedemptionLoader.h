#include <windows.h>
#include <string>

#import "libid:2D5E2D34-BED5-4B9F-9793-A31E26E6806E" rename_namespace("Redemption") raw_interfaces_only


 class RedemptionLoader
 {
 private:
     static RTL_CRITICAL_SECTION CritSection;
     static std::wstring DllLocation32Bit;
     static std::wstring DllLocation64Bit;
     static HMODULE DllHandle;

     static void CheckInitialize();
     ~RedemptionLoader();

 public:
	 static IUnknown* NewRedemptionObject(const GUID CLSID);

	 //The only creatable RDO object - RDOSession
	 static Redemption::IRDOSession* new_RDOSession();

	 //Safe*Item objects
	 static Redemption::ISafeMailItem* new_SafeMailItem();
	 static Redemption::ISafeContactItem* new_SafeContactItem();
	 static Redemption::ISafeAppointmentItem* new_SafeAppointmentItem();
	 static Redemption::ISafeTaskItem* new_SafeTaskItem();
	 static Redemption::ISafeJournalItem* new_SafeJournalItem();
	 static Redemption::ISafeMeetingItem* new_SafeMeetingItem();
	 static Redemption::ISafePostItem* new_SafePostItem();
	 static Redemption::ISafeReportItem* new_SafeReportItem();
	 static Redemption::ISafeMAPIFolder* new_SafeMAPIFolder();
	 static Redemption::ISafeDistList* new_ISafeDistList();
	 static Redemption::_IMAPITable* new_MAPITable();
	 static Redemption::ISafeInspector* new_SafeInspector();

	 __if_exists(Redemption::ISafeExplorer)
	 {
	 //Redemption 5.3 and higher
	 static Redemption::ISafeExplorer* new_SafeExplorer();
	 }

	 //deprecated object - please do not use
	 static Redemption::ISafeCurrentUser* new_SafeCurrentUser();
	 static Redemption::IAddressLists* new_AddressLists();
	 static Redemption::IMAPIUtils* new_MAPIUtils();

	 //dll locations
	 static void SetDllLocation32Bit(LPWSTR Value);
	 static void SetDllLocation64Bit(LPWSTR Value);

 };



